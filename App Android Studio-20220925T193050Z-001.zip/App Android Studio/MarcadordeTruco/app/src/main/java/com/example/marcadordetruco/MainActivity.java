package com.example.marcadordetruco;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText time1;
    EditText time2;
    TextView geral;
    TextView placar1;
    TextView placar2;
    int pontosEquipe1 = 0;
    int pontosEquipe2 = 0;
    int partidasEquipe1 = 0;
    int partidasEquipe2 = 0;
    String s1;
    Toast toast;
    String nome1, nome2;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        time1 = findViewById(R.id.editTextTextEquipe1);
        time2 = findViewById(R.id.editTextTextEquipe2);
        placar1 = findViewById(R.id.textViewPlacar1);
        placar2 = findViewById(R.id.textViewPlacar2);
        geral = findViewById(R.id.textViewGeral);

        s1 = "Equipe vencedora: ";

        geral.setText(partidasEquipe1 + "x" + partidasEquipe2);


    }


    public void somarEquipe1(View view) {
        pontosEquipe1 = pontosEquipe1 + 1;
        String y = String.valueOf(pontosEquipe1);
        placar1.setText(y);
        nome1 = time1.getText().toString();


        if (pontosEquipe1 == 12) {

            pontosEquipe1 = 0;
            pontosEquipe2 = 0;
            placar2.setText("0");
            placar1.setText("0");
            partidasEquipe1 = partidasEquipe1 + 1;
            geral.setText(partidasEquipe1 + "x" + partidasEquipe2);

            if(time1.getText().length() == 0){
                Toast.makeText(getApplicationContext(), "Equipe1 venceu", Toast.LENGTH_SHORT).show();
            }
            else {
                Toast.makeText(getApplicationContext(), s1.concat(nome1), Toast.LENGTH_SHORT).show();
            }

        }


    }

    public void somarEquipe2(View view) {
        pontosEquipe2 = pontosEquipe2 + 1;
        String x = String.valueOf(pontosEquipe2);
        placar2.setText(x);
        nome2 = time2.getText().toString();

        if (pontosEquipe2 == 12) {
            pontosEquipe2 = 0;
            pontosEquipe1 = 0;
            placar2.setText("0");
            placar1.setText("0");
            partidasEquipe2 = partidasEquipe2 + 1;
            geral.setText(partidasEquipe1 + "x" + partidasEquipe2);

            if(time2.getText().length() == 0){
                Toast.makeText(getApplicationContext(), "Equipe2 venceu", Toast.LENGTH_SHORT).show();
            }
            else {
                Toast.makeText(getApplicationContext(), s1.concat(nome2), Toast.LENGTH_SHORT).show();
            }
        }


    }

    public void subtraiEquipe1(View view) {

        pontosEquipe1 = pontosEquipe1 - 1;
        String y = String.valueOf(pontosEquipe1);
        placar1.setText(y);

        if (pontosEquipe1 < 0) {
            pontosEquipe1 = 0;
            placar1.setText("0");
        }
    }

    public void subtraiEquipe2(View view) {
        pontosEquipe2 = pontosEquipe2 - 1;
        String x = String.valueOf(pontosEquipe2);
        placar2.setText(x);

        if (pontosEquipe2 < 0) {
            pontosEquipe2 = 0;
            placar2.setText("0");
        }
    }

}